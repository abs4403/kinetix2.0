// KINETIX — Calorie Meter
// Tries the Flask API first (POST /api/bmr, /api/burn); if that's not
// running (e.g. the page was opened straight from disk), falls back to
// the same math computed locally so the calculator still works.
(function () {
  const GAUGE_CIRCUMFERENCE = 2 * Math.PI * 52; // r=52 from the SVG

  // ------------------------------------------------------------- tabs -----
  const tabs = document.querySelectorAll(".calorie-tab");
  const panels = {
    daily: document.getElementById("panel-daily"),
    burn: document.getElementById("panel-burn"),
  };

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("is-active"));
      tab.classList.add("is-active");
      Object.values(panels).forEach((p) => p.classList.remove("is-active"));
      panels[tab.dataset.tab].classList.add("is-active");
    });
  });

  // ------------------------------------------------------------ gauge -----
  function setGauge(arcEl, valueEl, value, unitMax) {
    const ratio = Math.max(0, Math.min(1, value / unitMax));
    const offset = GAUGE_CIRCUMFERENCE * (1 - ratio);
    arcEl.style.strokeDashoffset = offset;
    valueEl.textContent = Math.round(value).toLocaleString();
  }

  // ---------------------------------------------------- daily needs form --
  const dailyForm = document.getElementById("dailyForm");
  const dailyGaugeArc = document.getElementById("dailyGaugeArc");
  const dailyGaugeValue = document.getElementById("dailyGaugeValue");
  const dailyBreakdown = document.getElementById("dailyBreakdown");

  function computeBmrLocally({ sex, age, weight_kg, height_cm, activity_multiplier }) {
    const base = 10 * weight_kg + 6.25 * height_cm - 5 * age;
    const bmr = sex === "male" ? base + 5 : base - 161;
    const tdee = bmr * activity_multiplier;
    return { bmr: Math.round(bmr * 10) / 10, tdee: Math.round(tdee * 10) / 10 };
  }

  dailyForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = {
      sex: document.getElementById("sex").value,
      age: Number(document.getElementById("age").value),
      weight_kg: Number(document.getElementById("weight").value),
      height_cm: Number(document.getElementById("height").value),
      activity_multiplier: Number(document.getElementById("activity").value),
    };

    let result;
    try {
      const res = await fetch("/api/bmr", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("API unavailable");
      result = await res.json();
    } catch (err) {
      result = computeBmrLocally(payload);
    }

    setGauge(dailyGaugeArc, dailyGaugeValue, result.tdee, 4000);
    dailyBreakdown.innerHTML =
      `<b>${result.bmr.toLocaleString()}</b> kcal — base metabolic rate (BMR)<br>` +
      `<b>${result.tdee.toLocaleString()}</b> kcal — total daily energy expenditure (TDEE)`;
  });

  // -------------------------------------------------------- burn form -----
  const activitySelect = document.getElementById("activitySelect");
  const burnForm = document.getElementById("burnForm");
  const burnGaugeArc = document.getElementById("burnGaugeArc");
  const burnGaugeValue = document.getElementById("burnGaugeValue");
  const burnBreakdown = document.getElementById("burnBreakdown");

  let activityLibrary = [];

  async function loadActivities() {
    try {
      const [gymRes, yogaRes] = await Promise.all([
        fetch("/api/exercises"),
        fetch("/api/yoga"),
      ]);
      const gym = await gymRes.json();
      const yoga = await yogaRes.json();
      activityLibrary = [
        ...gym.map((e) => ({ label: `${e.name} (Gym)`, met: e.met })),
        ...yoga.map((p) => ({ label: `${p.name} (Yoga)`, met: p.met })),
      ];
    } catch (err) {
      // Static fallback if the Flask API isn't running.
      activityLibrary = [
        { label: "Push-Up (Gym)", met: 8.0 },
        { label: "Bodyweight Squat (Gym)", met: 5.0 },
        { label: "Deadlift (Gym)", met: 6.0 },
        { label: "Downward Facing Dog (Yoga)", met: 3.0 },
        { label: "Warrior II (Yoga)", met: 3.0 },
        { label: "Corpse Pose (Yoga)", met: 1.3 },
      ];
    }

    activitySelect.innerHTML = activityLibrary
      .map((a, i) => `<option value="${i}">${a.label}</option>`)
      .join("");
  }

  function computeBurnLocally({ met, weight_kg, minutes }) {
    const calories = met * weight_kg * (minutes / 60);
    return { calories_burned: Math.round(calories * 10) / 10 };
  }

  burnForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const activity = activityLibrary[Number(activitySelect.value)];
    if (!activity) return;

    const payload = {
      met: activity.met,
      weight_kg: Number(document.getElementById("burnWeight").value),
      minutes: Number(document.getElementById("minutes").value),
    };

    let result;
    try {
      const res = await fetch("/api/burn", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("API unavailable");
      result = await res.json();
    } catch (err) {
      result = computeBurnLocally(payload);
    }

    setGauge(burnGaugeArc, burnGaugeValue, result.calories_burned, 600);
    burnBreakdown.innerHTML =
      `<b>${activity.label}</b> at MET ${activity.met}<br>` +
      `${payload.minutes} minutes &middot; ${payload.weight_kg} kg`;
  });

  loadActivities();
})();
