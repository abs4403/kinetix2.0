// KINETIX — shared category/focus filtering for the gym and yoga pages.
(function () {
  function setupFilters(chipSelector, itemSelector, dataAttr) {
    const chips = document.querySelectorAll(chipSelector);
    const items = document.querySelectorAll(itemSelector);
    if (!chips.length || !items.length) return;

    chips.forEach((chip) => {
      chip.addEventListener("click", () => {
        chips.forEach((c) => c.classList.remove("is-active"));
        chip.classList.add("is-active");

        const filter = chip.dataset.filter;
        items.forEach((item) => {
          const matches = filter === "all" || item.dataset[dataAttr] === filter;
          item.style.display = matches ? "" : "none";
        });
      });
    });
  }

  setupFilters(".filter-chip", ".exercise-card", "category");
  setupFilters(".yoga-filter-chip", ".pose-entry", "focus");
})();
