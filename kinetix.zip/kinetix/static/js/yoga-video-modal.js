// KINETIX — opens a YouTube guided video in a lightweight modal (yoga page).
(function () {
  const modal = document.getElementById("yogaVideoModal");
  const iframe = document.getElementById("yogaVideoModalIframe");
  const closeBtn = document.getElementById("yogaVideoModalClose");
  if (!modal || !iframe) return;

  function openModal(videoId) {
    iframe.src = "https://www.youtube.com/embed/" + videoId + "?autoplay=1&rel=0";
    modal.classList.add("is-open");
  }

  function closeModal() {
    modal.classList.remove("is-open");
    iframe.src = "";
  }

  document.querySelectorAll(".pose-entry__thumb").forEach((btn) => {
    btn.addEventListener("click", () => openModal(btn.dataset.video));
  });

  closeBtn.addEventListener("click", closeModal);
  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeModal();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeModal();
  });
})();
