/* KINETIX shared behaviour: card rendering + filtering for gym/yoga
   pages, and the calorie meter (BMR/TDEE + per-activity burn estimate).
   No build step, no framework — plain DOM so the project stays easy
   to read, fork, and host as static files on GitHub Pages. */

function youtubeSearchUrl(query) {
  return "https://www.youtube.com/results?search_query=" + encodeURIComponent(query);
}

const PLAY_ICON = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';

function renderExerciseCards(container, list, kind) {
  container.innerHTML = list.map(item => {
    const label = kind === "gym" ? item.equipment : item.sanskrit;
    const query = kind === "gym"
      ? `${item.name} proper form tutorial`
      : `${item.name} ${item.sanskrit} yoga pose tutorial`;
    const sub = kind === "gym"
      ? `<span class="part">${item.part} · ${item.equipment}</span>`
      : `<span class="part">${item.part}</span>`;
    const sanskritLine = kind === "yoga" ? `<div class="sanskrit">${item.sanskrit}</div>` : "";
    return `
      <article class="${kind === "gym" ? "ex-card" : "pose-card"}">
        ${sub}
        <h3>${item.name}</h3>
        ${sanskritLine}
        <p>${item.desc}</p>
        <div class="meta">
          <span>${item.level}</span>
          <a class="demo-link" target="_blank" rel="noopener" href="${youtubeSearchUrl(query)}">
            ${PLAY_ICON} Watch demo
          </a>
        </div>
      </article>`;
  }).join("");
}

function wireFilters(filterRow, allParts, onSelect) {
  filterRow.innerHTML = ["All", ...allParts].map(p =>
    `<button data-part="${p}" class="${p === "All" ? "active" : ""}">${p}</button>`
  ).join("");
  filterRow.addEventListener("click", e => {
    const btn = e.target.closest("button");
    if (!btn) return;
    filterRow.querySelectorAll("button").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    onSelect(btn.dataset.part);
  });
}

function initListPage(containerId, filterRowId, data, kind) {
  const container = document.getElementById(containerId);
  const filterRow = document.getElementById(filterRowId);
  if (!container) return;
  const parts = [...new Set(data.map(d => d.part))];
  renderExerciseCards(container, data, kind);
  wireFilters(filterRow, parts, part => {
    const filtered = part === "All" ? data : data.filter(d => d.part === part);
    renderExerciseCards(container, filtered, kind);
  });
}

/* ---------------- Calorie meter ---------------- */

function mifflinStJeorBMR({ sex, weightKg, heightCm, age }) {
  const base = 10 * weightKg + 6.25 * heightCm - 5 * age;
  return sex === "male" ? base + 5 : base - 161;
}

const ACTIVITY_MULTIPLIERS = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  active: 1.725,
  athlete: 1.9,
};

function caloriesBurnedPerMinute(met, weightKg) {
  return (met * 3.5 * weightKg) / 200;
}

function initCalorieMeter() {
  const form = document.getElementById("cal-form");
  if (!form) return;

  const unitButtons = form.querySelectorAll(".unit-toggle button");
  let unit = "metric";
  unitButtons.forEach(b => b.addEventListener("click", () => {
    unit = b.dataset.unit;
    unitButtons.forEach(x => x.classList.toggle("active", x === b));
    form.querySelectorAll("[data-metric]").forEach(el => el.style.display = unit === "metric" ? "" : "none");
    form.querySelectorAll("[data-imperial]").forEach(el => el.style.display = unit === "imperial" ? "" : "none");
  }));

  const activitySelect = document.getElementById("cal-activity");
  const burnSelect = document.getElementById("cal-burn-select");
  const burnDuration = document.getElementById("cal-burn-duration");
  const burnOut = document.getElementById("cal-burn-out");

  const allActivities = [
    ...EXERCISES.map(e => ({ ...e, group: "Gym" })),
    ...YOGA_POSES.map(y => ({ ...y, group: "Yoga" })),
  ];
  burnSelect.innerHTML = allActivities.map((a, i) =>
    `<option value="${i}">${a.group} — ${a.name}</option>`
  ).join("");

  let lastWeightKg = null;

  function updateBurn() {
    if (lastWeightKg == null) {
      burnOut.textContent = "Enter your details and calculate first.";
      return;
    }
    const activity = allActivities[burnSelect.value];
    const minutes = parseFloat(burnDuration.value) || 0;
    const kcal = caloriesBurnedPerMinute(activity.met, lastWeightKg) * minutes;
    burnOut.innerHTML = `<strong>${Math.round(kcal)} kcal</strong> estimated for ${minutes} min of ${activity.name.toLowerCase()}.`;
  }
  burnSelect.addEventListener("change", updateBurn);
  burnDuration.addEventListener("input", updateBurn);

  form.addEventListener("submit", e => {
    e.preventDefault();
    const sex = form.sex.value;
    const age = parseFloat(form.age.value);
    let weightKg, heightCm;
    if (unit === "metric") {
      weightKg = parseFloat(form.weightKg.value);
      heightCm = parseFloat(form.heightCm.value);
    } else {
      weightKg = parseFloat(form.weightLb.value) * 0.453592;
      heightCm = parseFloat(form.heightFt.value) * 30.48 + parseFloat(form.heightIn.value || 0) * 2.54;
    }
    if (!age || !weightKg || !heightCm) return;

    const bmr = mifflinStJeorBMR({ sex, weightKg, heightCm, age });
    const tdee = bmr * ACTIVITY_MULTIPLIERS[activitySelect.value];
    const bmi = weightKg / Math.pow(heightCm / 100, 2);

    document.getElementById("out-bmr").textContent = Math.round(bmr);
    document.getElementById("out-tdee").textContent = Math.round(tdee);
    document.getElementById("out-bmi").textContent = bmi.toFixed(1);

    lastWeightKg = weightKg;
    updateBurn();
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initCalorieMeter();
  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();
});
